import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import styled from 'styled-components';
import PrizeApplication from './components/PrizeApplication';
import CompletePage from './components/CompletePage';
import PrizePage from './components/PrizePage';
import VRFDrawingPage from './components/VRFDrawingPage';

const AppContainer = styled.div`
  width: 100%;
  height: 100vh;
  background-color: #F7F8F9;
  display: flex;
  justify-content: center;
  align-items: center;
`;

function App() {
  return (
    <Router>
      <AppContainer>
        <Routes>
          <Route path="/" element={<PrizeApplication />} />
          <Route path="/complete" element={<CompletePage />} />
          <Route path="/vrf-drawing" element={<VRFDrawingPage />} />
          <Route path="/prize" element={<PrizePage />} />
        </Routes>
      </AppContainer>
    </Router>
  );
}

export default App;

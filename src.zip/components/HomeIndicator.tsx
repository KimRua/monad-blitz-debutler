import React from 'react';
import styled from 'styled-components';

const HomeIndicatorContainer = styled.div`
  width: 375px;
  height: 34px;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 21px 0;
`;

const HomeIndicatorBar = styled.div`
  width: 134px;
  height: 5px;
  background-color: #000000;
  border-radius: 2.5px;
  backdrop-filter: blur(44px);
`;

const HomeIndicator: React.FC = () => {
  return (
    <HomeIndicatorContainer>
      <HomeIndicatorBar />
    </HomeIndicatorContainer>
  );
};

export default HomeIndicator;

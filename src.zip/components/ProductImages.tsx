import React from 'react';
import styled from 'styled-components';

const ProductImagesContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;
  width: 100%;
`;

const ProductImage = styled.div<{ width: number; height: number; imageUrl: string }>`
  width: ${props => props.width}px;
  height: ${props => props.height}px;
  background-image: url(${props => props.imageUrl});
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  border-radius: 10px;
  flex-shrink: 0;
`;

const ProductImages: React.FC = () => {
  return (
    <ProductImagesContainer>
      <ProductImage width={98} height={98} imageUrl="/images/1st.png" />
      <ProductImage width={97} height={97} imageUrl="/images/2nd.png" />
      <ProductImage width={98} height={98} imageUrl="/images/3rd.png" />
    </ProductImagesContainer>
  );
};

export default ProductImages;

import React from 'react';

const PhoneIcon: React.FC = () => {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M17.5 14.5C16.5 14.5 15.5 14.3 14.6 13.9C14.3 13.8 13.9 13.9 13.7 14.1L12.1 15.7C9.4 14.2 6.8 11.6 5.3 8.9L6.9 7.3C7.1 7.1 7.2 6.7 7.1 6.4C6.7 5.5 6.5 4.5 6.5 3.5C6.5 3.2 6.3 3 6 3H2.5C2.2 3 2 3.2 2 3.5C2 10.8 8.2 17 15.5 17C15.8 17 16 16.8 16 16.5V13C16 12.7 15.8 12.5 15.5 12.5H17.5Z" fill="#BDBDBD"/>
    </svg>
  );
};

export default PhoneIcon;

import React from 'react';

const CompanyIcon: React.FC = () => {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 0L20 5V20H0V5L10 0ZM2 7V18H8V12H12V18H18V7L10 2.5L2 7Z" fill="#BDBDBD"/>
    </svg>
  );
};

export default CompanyIcon;

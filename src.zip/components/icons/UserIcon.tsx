import React from 'react';

const UserIcon: React.FC = () => (
  <svg width="28" height="26" viewBox="0 0 28 26" fill="none" xmlns="http://www.w3.org/2000/svg">
    <mask id="mask0_98_261" style={{maskType: 'luminance'}} maskUnits="userSpaceOnUse" x="0" y="0" width="28" height="26">
      <path d="M0 0.5H28V25.5H0V0.5Z" fill="white"/>
    </mask>
    <g mask="url(#mask0_98_261)">
      <path d="M9.67575 13.8687L9.674 13.8641C9.674 12.2188 6.65 11.4375 6.65 7.375C6.65 3.60469 9.912 0.5 14 0.5C18.088 0.5 21.35 3.60469 21.35 7.375C21.35 11.4375 18.326 12.2188 18.326 13.8641V13.8687C18.326 16.2609 26.25 16.3828 26.25 20.6703C26.25 25.6031 17.563 25.5 14 25.5C10.437 25.5 1.75 25.6031 1.75 20.6719C1.75 16.3828 9.67575 16.2609 9.67575 13.8687Z" fill="#131517" fillOpacity="0.2"/>
    </g>
  </svg>
);

export default UserIcon;

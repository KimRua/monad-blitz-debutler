import React from 'react';
import styled from 'styled-components';
import StatusBar from './StatusBar';
import HomeIndicator from './HomeIndicator';
import CloverIcon from './icons/CloverIcon';

const Container = styled.div`
  width: 375px;
  height: 812px;
  background-color: #F7F8F9;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
`;

const ContentContainer = styled.div`
  width: 269px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 43px;
  margin-top: 175px;
`;

const HeaderSection = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const IconContainer = styled.div`
  width: 37px;
  height: 37px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
`;

const Title = styled.h1`
  font-family: Pretendard;
  font-weight: 700;
  font-size: 32px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: left;
  color: #131517;
  margin: 0;
`;

const ProductSection = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  width: 201px;
`;

const ProductImage = styled.div`
  width: 100%;
  height: 201px;
  background-image: url('/images/1st.png');
  background-size: cover;
  background-position: center;
  border-radius: 30.81px;
`;

const ProductName = styled.span`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 16px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #131517;
`;

const MessageSection = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 37px;
  width: 100%;
`;

const MainMessage = styled.h2`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 22px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #131517;
  margin: 0;
`;

const HighlightedText = styled.span`
  color: #FF6B6B;
`;

const SubMessage = styled.p`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 16px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #131517;
  margin: 0;
`;

const Divider = styled.div`
  width: 335px;
  height: 0.5px;
  background-color: rgba(189, 189, 189, 0.2);
  position: absolute;
  top: 110px;
  left: 20px;
`;

const BottomContainer = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: rgba(255, 255, 255, 0);
  backdrop-filter: blur(64px);
`;

const PrizePage: React.FC = () => {
  return (
    <Container>
      <StatusBar />
      <Divider />
      
      <ContentContainer>
        <HeaderSection>
          <IconContainer>
            <CloverIcon />
          </IconContainer>
          <Title>축하합니다!</Title>
          <IconContainer>
            <CloverIcon />
          </IconContainer>
        </HeaderSection>
        
        <ProductSection>
          <ProductImage />
          <ProductName>경품명</ProductName>
        </ProductSection>
        
        <MessageSection>
          <MainMessage>
            102번님, <HighlightedText>1등 경품</HighlightedText> 당첨입니다!
          </MainMessage>
          <SubMessage>행사 종료 전 반드시 경품을 수령하세요!</SubMessage>
        </MessageSection>
      </ContentContainer>

      <BottomContainer>
        <HomeIndicator />
      </BottomContainer>
    </Container>
  );
};

export default PrizePage;

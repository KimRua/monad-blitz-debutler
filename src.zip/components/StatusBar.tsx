import React from 'react';
import styled from 'styled-components';

const StatusBarContainer = styled.div`
  width: 375px;
  height: 44px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 30.5px;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
`;

const Time = styled.div`
  font-family: 'SF Pro', -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: 590;
  font-size: 15px;
  line-height: 1.193;
  letter-spacing: -1.58%;
  color: #000000;
`;

const StatusIcons = styled.div`
  display: flex;
  align-items: center;
  gap: 4px;
`;

const CellularIcon = styled.div`
  width: 18px;
  height: 12px;
  display: flex;
  align-items: flex-end;
  gap: 1px;
`;

const CellularBar = styled.div<{ height: number }>`
  width: 3px;
  height: ${props => props.height}px;
  background-color: #000000;
  border-radius: 1px;
`;

const WifiIcon = styled.div`
  width: 16px;
  height: 12px;
  position: relative;
  
  &::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 12px;
    height: 12px;
    border: 2px solid #000000;
    border-top: none;
    border-left: none;
    border-right: none;
    border-radius: 0 0 12px 12px;
  }
`;

const BatteryIcon = styled.div`
  width: 25px;
  height: 12px;
  position: relative;
  display: flex;
  align-items: center;
`;

const BatteryBody = styled.div`
  width: 22px;
  height: 11.33px;
  border: 1px solid rgba(0, 0, 0, 0.4);
  border-radius: 3px;
  position: relative;
`;

const BatteryLevel = styled.div`
  width: 18px;
  height: 7.33px;
  background-color: #000000;
  border-radius: 1.33px;
  position: absolute;
  top: 2px;
  left: 2px;
`;

const BatteryCap = styled.div`
  width: 1.33px;
  height: 4px;
  background-color: rgba(0, 0, 0, 0.5);
  position: absolute;
  right: -1.33px;
  top: 3.67px;
`;

const StatusBar: React.FC = () => {
  return (
    <StatusBarContainer>
      <Time>9:41</Time>
      <StatusIcons>
        <CellularIcon>
          <CellularBar height={4} />
          <CellularBar height={6} />
          <CellularBar height={8.33} />
          <CellularBar height={10.67} />
        </CellularIcon>
        <WifiIcon />
        <BatteryIcon>
          <BatteryBody>
            <BatteryLevel />
          </BatteryBody>
          <BatteryCap />
        </BatteryIcon>
      </StatusIcons>
    </StatusBarContainer>
  );
};

export default StatusBar;

import React from 'react';
import styled from 'styled-components';
import MetamaskIcon from './icons/MetamaskIcon';

interface SubmitButtonProps {
  onClick: () => void;
  disabled: boolean;
}

const Button = styled.button<{ disabled: boolean }>`
  width: 340px;
  height: 47px;
  background-color: ${props => props.disabled ? '#69737D' : '#228CF6'};
  border: none;
  border-radius: 23.95px;
  cursor: ${props => props.disabled ? 'not-allowed' : 'pointer'};
  transition: all 0.2s ease;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 8px;
  
  &:hover {
    background-color: ${props => props.disabled ? '#69737D' : '#1A7CD9'};
    transform: ${props => props.disabled ? 'none' : 'translateY(-1px)'};
  }
  
  &:active {
    transform: ${props => props.disabled ? 'none' : 'translateY(0)'};
  }
`;

const ButtonText = styled.span`
  font-family: Pretendard;
  font-weight: 400;
  font-size: 18px;
  line-height: 1.193;
  letter-spacing: -3%;
  color: #F2F2F2;
  text-align: center;
`;

const SubmitButton: React.FC<SubmitButtonProps> = ({ onClick, disabled }) => {
  return (
    <Button onClick={onClick} disabled={disabled}>
      <MetamaskIcon />
      <ButtonText>메타마스크 지갑 연동하기</ButtonText>
    </Button>
  );
};

export default SubmitButton;

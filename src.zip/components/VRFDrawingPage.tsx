import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import StatusBar from './StatusBar';
import HomeIndicator from './HomeIndicator';

const Container = styled.div`
  width: 375px;
  height: 812px;
  background-color: #F7F8F9;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
`;

const ContentContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
  text-align: center;
`;

const Title = styled.h1`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 24px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #131517;
  margin: 0;
`;

const BottomContainer = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: rgba(255, 255, 255, 0);
  backdrop-filter: blur(64px);
`;

const VRFDrawingPage: React.FC = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/prize');
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <Container>
      <StatusBar />
      
      <ContentContainer>
        <Title>VRF를 통해<br />공정하게 추첨 진행 중입니다...</Title>
      </ContentContainer>

      <BottomContainer>
        <HomeIndicator />
      </BottomContainer>
    </Container>
  );
};

export default VRFDrawingPage;

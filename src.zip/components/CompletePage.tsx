import React from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import StatusBar from './StatusBar';
import HomeIndicator from './HomeIndicator';
import ClockIcon from './icons/ClockIcon';
import NumberIcon from './icons/NumberIcon';
import UsersIcon from './icons/UsersIcon';
import MoneyIcon from './icons/MoneyIcon';

const Container = styled.div`
  width: 375px;
  height: 812px;
  background-color: #F7F8F9;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
`;

const ContentContainer = styled.div`
  width: 335px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 18px;
  margin-top: 89px;
`;

const TitleSection = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 10px;
  padding: 10px;
`;

const Title = styled.h1`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 32px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: left;
  color: #131517;
  margin: 0;
`;

const TimeSection = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const TimeIcon = styled.div`
  width: 29px;
  height: 29px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #131517;
`;

const TimeText = styled.span`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 16px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #131517;
`;

const MainImage = styled.div`
  width: 100%;
  height: 335px;
  background-image: url('/images/main-product.png');
  background-size: cover;
  background-position: center;
  border-radius: 10px;
`;

const NumberSection = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const NumberIconContainer = styled.div`
  width: 24px;
  height: 24px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #131517;
`;

const NumberText = styled.span`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 16px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #131517;
`;

const ParticipantsSection = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const ParticipantsIcon = styled.div`
  width: 20px;
  height: 20px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ParticipantsText = styled.span`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 16px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #000000;
`;

const CheckButton = styled.button`
  width: 217px;
  height: 47px;
  background-color: #69737D;
  border: none;
  border-radius: 23.95px;
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 6px;
  padding: 16px 32px;

  &:hover {
    background-color: #5A636C;
    transform: translateY(-1px);
  }

  &:active {
    transform: translateY(0);
  }
`;

const MoneyIconContainer = styled.div`
  width: 25px;
  height: 25px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
`;

const ButtonText = styled.span`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 18.96px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #F2F2F2;
`;

const BottomContainer = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: rgba(255, 255, 255, 0);
  backdrop-filter: blur(64px);
`;

const CompletePage: React.FC = () => {
  const navigate = useNavigate();
  
  const handleCheckResult = () => {
    navigate('/vrf-drawing');
  };

  return (
    <Container>
      <StatusBar />
      
      <ContentContainer>
        <TitleSection>
          <Title>응모가 완료되었습니다!</Title>
        </TitleSection>
        
        <TimeSection>
          <TimeIcon>
            <ClockIcon />
          </TimeIcon>
          <TimeText>남은 추첨 시간 : 10시간 10분</TimeText>
        </TimeSection>
        
        <MainImage />
        
        <NumberSection>
          <NumberIconContainer>
            <NumberIcon />
          </NumberIconContainer>
          <NumberText>응모 번호 : 102번</NumberText>
        </NumberSection>
        
        <ParticipantsSection>
          <ParticipantsIcon>
            <UsersIcon />
          </ParticipantsIcon>
          <ParticipantsText>현재 응모 인원 : 102명</ParticipantsText>
        </ParticipantsSection>
        
        <CheckButton onClick={handleCheckResult}>
          <MoneyIconContainer>
            <MoneyIcon />
          </MoneyIconContainer>
          <ButtonText>당첨 확인</ButtonText>
        </CheckButton>
      </ContentContainer>

      <BottomContainer>
        <HomeIndicator />
      </BottomContainer>
    </Container>
  );
};

export default CompletePage;

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import StatusBar from './StatusBar';
import HomeIndicator from './HomeIndicator';
import ProductImages from './ProductImages';
import InputFields from './InputFields';
import SubmitButton from './SubmitButton';

const Container = styled.div`
  width: 375px;
  height: 812px;
  background-color: #F7F8F9;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  font-family: 'Pretendard', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
`;

const ContentContainer = styled.div`
  width: 335px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 50px;
  margin-top: 158.5px;
`;

const HeaderSection = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 31px;
  width: 100%;
`;

const TextSection = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 36px;
  width: 263px;
`;

const EventTitle = styled.h1`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 32px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: center;
  color: #228CF6;
  margin: 0;
`;

const EventSubtitle = styled.h2`
  font-family: Pretendard;
  font-weight: 500;
  font-size: 22px;
  line-height: 1.193;
  letter-spacing: -3%;
  text-align: left;
  color: #131517;
  margin: 0;
`;

const BottomContainer = styled.div`
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: rgba(255, 255, 255, 0);
  backdrop-filter: blur(64px);
`;

const PrizeApplication: React.FC = () => {
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');

  const handleNameChange = (value: string) => {
    setName(value);
  };

  const handlePhoneChange = (value: string) => {
    setPhone(value);
  };

  const handleEmailChange = (value: string) => {
    setEmail(value);
  };

  const handleCompanyChange = (value: string) => {
    setCompany(value);
  };

  const handleSubmit = () => {
    if (!name.trim()) {
      alert('이름을 입력해주세요.');
      return;
    }
    if (!phone.trim()) {
      alert('전화번호를 입력해주세요.');
      return;
    }
    if (!email.trim()) {
      alert('이메일 주소를 입력해주세요.');
      return;
    }
    
    navigate('/complete');
  };

  return (
    <Container>
      <StatusBar />
      
      <ContentContainer>
        <HeaderSection>
          <TextSection>
            <EventTitle>이벤트 이름</EventTitle>
            <EventSubtitle>경품 당첨 기회에 도전하세요!</EventSubtitle>
          </TextSection>
          <ProductImages />
        </HeaderSection>
        
        <InputFields 
          walletConnected={false}
          name={name}
          phone={phone}
          email={email}
          company={company}
          onWalletConnect={() => {}}
          onNameChange={handleNameChange}
          onPhoneChange={handlePhoneChange}
          onEmailChange={handleEmailChange}
          onCompanyChange={handleCompanyChange}
        />
        
        <SubmitButton 
          onClick={handleSubmit}
          disabled={!name.trim() || !phone.trim() || !email.trim()}
        />
      </ContentContainer>

      <BottomContainer>
        <HomeIndicator />
      </BottomContainer>
    </Container>
  );
};

export default PrizeApplication;

import React from 'react';
import styled from 'styled-components';
import WalletIcon from './icons/WalletIcon';
import UserIcon from './icons/UserIcon';
import PhoneIcon from './icons/PhoneIcon';
import EmailIcon from './icons/EmailIcon';
import CompanyIcon from './icons/CompanyIcon';

interface InputFieldsProps {
  walletConnected: boolean;
  name: string;
  phone: string;
  email: string;
  company: string;
  onWalletConnect: () => void;
  onNameChange: (value: string) => void;
  onPhoneChange: (value: string) => void;
  onEmailChange: (value: string) => void;
  onCompanyChange: (value: string) => void;
}

const InputFieldsContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
  width: 100%;
`;

const InputField = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 20px;
  background-color: #FDFEFE;
  border-radius: 10px;
  height: 47px;
  box-sizing: border-box;
`;

const IconContainer = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const InputText = styled.input`
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  font-family: Pretendard;
  font-weight: 500;
  font-size: 16px;
  line-height: 1.193;
  letter-spacing: -1.58%;
  color: ${props => props.value ? '#131517' : '#BDBDBD'};
  
  &::placeholder {
    color: #BDBDBD;
  }
  
  &:focus {
    color: #131517;
  }
`;




const InputFields: React.FC<InputFieldsProps> = ({
  walletConnected,
  name,
  phone,
  email,
  company,
  onWalletConnect,
  onNameChange,
  onPhoneChange,
  onEmailChange,
  onCompanyChange
}) => {
  return (
    <InputFieldsContainer>
      
      
      <InputField>
        <IconContainer>
          <UserIcon />
        </IconContainer>
        <InputText
          type="text"
          placeholder="닉네임을 입력해주세요..."
          value={name}
          onChange={(e) => onNameChange(e.target.value)}
        />
      </InputField>
      
      <InputField>
        <IconContainer>
          <PhoneIcon />
        </IconContainer>
        <InputText
          type="tel"
          placeholder="전화번호를 입력해주세요..."
          value={phone}
          onChange={(e) => onPhoneChange(e.target.value)}
        />
      </InputField>
      
      <InputField>
        <IconContainer>
          <EmailIcon />
        </IconContainer>
        <InputText
          type="email"
          placeholder="이메일 주소를 입력해주세요..."
          value={email}
          onChange={(e) => onEmailChange(e.target.value)}
        />
      </InputField>
    </InputFieldsContainer>
  );
};

export default InputFields;
